<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Nurture">

    <!-- ========== Page Title ========== -->
    <title>Nurture</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="<?php echo e(asset ('img/logo.jpeg')); ?>" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset ('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/flaticon-set.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/owl.theme.default.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/bootsnav.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset ('css/responsive.css')); ?>" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="assets/js/html5/html5shiv.min.js"></script>
      <script src="assets/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">

</head>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Start Header Top 
    ============================================= -->
   
    <!-- End Header Top -->
    
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('content'); ?>

    <!-- Start Footer 
    ============================================= -->
   <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset ('js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/bootstrap.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset ('js/bootstrap.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset ('js/equal-height.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/progress-bar.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/YTPlayer.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/loopcounter.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/main.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH /home/hillux/Desktop/Nurture-LMS/nurture_lms/resources/views/master.blade.php ENDPATH**/ ?>